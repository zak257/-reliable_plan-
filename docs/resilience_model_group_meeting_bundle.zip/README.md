# 阅读说明

文档已经修复 VS Code Markdown 预览中的图片路径与温度公式兼容问题。

- Markdown：解压全部文件后，用 VS Code 打开 resilience_model_group_meeting.md，再打开预览。保留 assets/ 目录与 Markdown 文件的相对位置。
- 离线网页：用浏览器打开 resilience_model_group_meeting.html。六张图、149处公式与数学字体均已嵌入，一个HTML文件即可阅读，不需要联网或公式插件。
- assets/：PNG、SVG和统计数据，以及公式与浏览器渲染核验记录。
- data/：冻结的8760小时输入及参数。
- source/：引用的模型定义快照。
- scripts/：原仓库使用的图表与HTML生成脚本，重新运行时需配置本地路径。

这是模型说明阅读包，不包含新的规划结果。
